﻿Boardlike 中文汉化补丁整合包（已包含 BepInEx）

安装：
1. 完全退出 Boardlike 游戏。
2. Steam 游戏库右键 Boardlike → 管理 → 浏览本地文件，确认能直接看到 Boardlike.exe。
3. 打开本 ZIP，直接将压缩包根目录里的 BepInEx 文件夹、winhttp.dll、doorstop_config.ini 和 .doorstop_version 解压或复制到 Boardlike.exe 所在文件夹；不要再创建 Boardlike_Chinese_Patch_Release 子文件夹。若 Windows 自动创建外层包装文件夹，请打开它并复制里面的内容，而不是整个外层文件夹。
4. 启动 Boardlike，选择简体中文。

正确路径：
Boardlike/Boardlike.exe
Boardlike/BepInEx/core/BepInEx.dll
Boardlike/BepInEx/plugins/BoardlikeChinese/BoardlikeChinese.dll
Boardlike/winhttp.dll
Boardlike/doorstop_config.ini

如果不起作用：
启动游戏一次后，查找 Boardlike/BepInEx/LogOutput.log，检查是否有加载错误。
勿将本补丁安装到 Project Hospital 等其他游戏。
本包未经当前会话中的全新 Windows 游戏环境 L4 实测；但发布资源内容和 ZIP 压缩完整性均已校验。
